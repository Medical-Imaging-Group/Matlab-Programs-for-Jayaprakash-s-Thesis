function [ Omega rn   ]= ObjectiveFunction(mesh, anom,ref,...
                                                 foo, J, data_diff,lambda )

%     omega_0 = norm(data_diff,2)^2;                                     
     [ foo_MRM rn ]= MRM(J,foo,data_diff,lambda,1)  ;                              
                                     
                                        

     
     
      foo_MRM = foo_MRM.*[mesh.mua];                                         
   mesh.mua = mesh.mua + foo_MRM;
   mesh.kappa = 1./(3.*(mesh.mua + mesh.mus));
%     figure;
%     plotimage( mesh,mesh.mua);title(num2str(lambda));
    
   
   data = femdata('circular_mesh',0,mesh);    
% % % % % %    Read reference data
    clear ref;
    ref = log(data.amplitude);    
    data_diff = (anom-ref);    
     Omega = norm(data_diff)^2%+ lambda*norm(foo_MRM)^2;
     rn






% % Updating the jacobian
%  foo_MRM = foo_MRM.*[mesh.mua]; 
%   J = J*diag([mesh.mua]);
% [~,ncol]=size(J);
% x  = (1 + foo_MRM./ mesh.mua).^(-0.5);
% 
%    for i = 1 : ncol
%        J(:,i) = J(:,i).*x(i);
%    end
%     M= J*foo_MRM ;ref = (M) +ref;
%    data_diff =  (anom-ref); 
% 
% lambda
% %    Omega =  norm(J*foo_MRM - data_diff)^2+ lambda*norm(foo_MRM)^2
%    Omega = norm(data_diff)^2; 




    
   
   