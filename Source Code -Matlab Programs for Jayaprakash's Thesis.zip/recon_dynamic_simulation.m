clc;
clear all;
close all;

for i=0:4

    close all;
    
mesh = load_mesh('circle_10249_86_16_2d');

blob.x = 15;
blob.y = 0;
blob.r = 7.5;
blob.mua = 0.02+i*0.005;
blob.mus = 1;
blob.ri = 1.33;
blob.region = 2;

mesh_anom = add_blob(mesh,blob);
save_mesh(mesh_anom,'circle_10249_86_target')

%mu
mesh_anom = load_mesh('circle_10249_86_target');
x_target = TriScatteredInterp(mesh_anom.nodes(:,1),mesh_anom.nodes(:,2),mesh_anom.mua);
 
[data, mesh] = femdata('circle_10249_86_target', 0);
mysave('circle_10249_86_target_data.paa',data.paa);
 
 
% Add noise
add_noise('circle_10249_86_target_data.paa',1,0,...
    'circle_10249_86_target_data_N1.paa');
 
% Homogenous data
[data, mesh] = femdata('circle_10249_86', 0);
mysave('circle_10249_86_data.paa',data.paa);
 

% % % % % % % % % % % % % % % % % % % % % % % %
 
homog_data =        'circle_10249_86_data.paa';
anom_data  =        'circle_10249_86_target_data_N1.paa';
 
mesh_fn_homog =     'circle_1933_86';
mesh_homog_radius =  43;
mesh_fn_anom =      'circle_1933_86';
mesh_anom_radius =   43;
mus                =  1;
mesh_op =            'circle_1933_86_stnd_calibrated_mesh';
data_op =            'circle_1933_86_stnd_calibrated_data.paa';
 
frequency=            0;
iteration=            5;
 
calibrate_cw_modified(homog_data,...
              anom_data,...
              mesh_fn_homog,...
              mesh_homog_radius,...
              mesh_fn_anom,...
              mesh_anom_radius,...
              mus,...
              mesh_op, ...
              data_op,...
              frequency,...
              iteration)
                   

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STANDARD JtJ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
          tic;
fwd_fn = 'circle_1933_86_stnd_calibrated_mesh';
data_fn = 'circle_1933_86_stnd_calibrated_data.paa';
% fwd_fn = 'circle_10249_86';
% data_fn = 'circle_10249_86_target_data_N1.paa';
iteration = 1000;
lambda.value = 1;
lambda.type = 'JJt';
output_fn = ['recon_circle_1933_86_stnd_calibrated_005_JJT_edge' num2str(i)];
filter_n=0;
 

[fwd_mesh,pj_error] = reconstruct_stnd_cw_fwd(fwd_fn,...
                                   data_fn,...
                                   iteration,...
                                   lambda,...
                                   output_fn,...
                                   filter_n);
                              
          toc                    
mesh = load_mesh('circle_1933_86');
mesh1 = read_solution(mesh,output_fn);

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Optimized Routine %%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 
tic;
fwd_fn = 'circle_1933_86_stnd_calibrated_mesh';
data_fn = 'circle_1933_86_stnd_calibrated_data.paa';
fwd_mesh = load_mesh(fwd_fn);
% fwd_fn = 'cylinder_43_100_31446';
% data_fn = 'cylinder_43_100_31446_target_singleblob_data_N1.paa';
frequency=0;
iteration = 200;
lambda.value = 1;
lambda.type = 'JtJ';
output_fn = ['recon_circle_1933_86_back_calibrated_005_edge' num2str(i)];
filter_n=0;

[fwd_mesh,pj_error] = reconstruct_stnd_cw_opt_fwd_exp(fwd_mesh,...
                                   data_fn,...
                                   iteration,...
                                   output_fn,...
                                   filter_n);
                              toc
mesh = load_mesh('circle_1933_86');
mesh1 = read_solution(mesh,output_fn);

end

for i=5:8

    close all;
    
mesh = load_mesh('circle_10249_86_16_2d');

blob.x = 15;
blob.y = 0;
blob.r = 7.5;
blob.mua = 0.04-(i-4)*0.005; %0.09 for 0.01
blob.mus = 1;
blob.ri = 1.33;
blob.region = 2;

mesh_anom = add_blob(mesh,blob);
save_mesh(mesh_anom,'circle_10249_86_target')

%mu
mesh_anom = load_mesh('circle_10249_86_target');
x_target = TriScatteredInterp(mesh_anom.nodes(:,1),mesh_anom.nodes(:,2),mesh_anom.mua);
 
[data, mesh] = femdata('circle_10249_86_target', 0);
mysave('circle_10249_86_target_data.paa',data.paa);
 
 
% Add noise
add_noise('circle_10249_86_target_data.paa',1,0,...
    'circle_10249_86_target_data_N1.paa');
 
% Homogenous data
[data, mesh] = femdata('circle_10249_86', 0);
mysave('circle_10249_86_data.paa',data.paa);
 

% % % % % % % % % % % % % % % % % % % % % % % %
 
homog_data =        'circle_10249_86_data.paa';
anom_data  =        'circle_10249_86_target_data_N1.paa';
 
mesh_fn_homog =     'circle_1933_86';
mesh_homog_radius =  43;
mesh_fn_anom =      'circle_1933_86';
mesh_anom_radius =   43;
mus                =  1;
mesh_op =            'circle_1933_86_stnd_calibrated_mesh';
data_op =            'circle_1933_86_stnd_calibrated_data.paa';
 
frequency=            0;
iteration=            5;
 
calibrate_cw_modified(homog_data,...
              anom_data,...
              mesh_fn_homog,...
              mesh_homog_radius,...
              mesh_fn_anom,...
              mesh_anom_radius,...
              mus,...
              mesh_op, ...
              data_op,...
              frequency,...
              iteration)
                   

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STANDARD JtJ%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
%           
% fwd_fn = 'circle_1933_86_stnd_calibrated_mesh';
% data_fn = 'circle_1933_86_stnd_calibrated_data.paa';
% % fwd_fn = 'circle_10249_86';
% % data_fn = 'circle_10249_86_target_data_N1.paa';
% iteration = 1000;
% lambda.value = 1;
% lambda.type = 'JtJ';
% output_fn = ['recon_circle_1933_86_stnd_calibrated_005_edge' num2str(i)];
% filter_n=0;
%  
% 
% [fwd_mesh,pj_error] = reconstruct_stnd_cw_fwd(fwd_fn,...
%                                    data_fn,...
%                                    iteration,...
%                                    lambda,...
%                                    output_fn,...
%                                    filter_n);
%                               
%                               
% mesh = load_mesh('circle_1933_86');
% mesh1 = read_solution(mesh,output_fn);

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Optimized Routine %%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 

fwd_fn = 'circle_1933_86_stnd_calibrated_mesh';
data_fn = 'circle_1933_86_stnd_calibrated_data.paa';
fwd_mesh = load_mesh(fwd_fn);
% fwd_fn = 'cylinder_43_100_31446';
% data_fn = 'cylinder_43_100_31446_target_singleblob_data_N1.paa';
frequency=0;
iteration = 200;
lambda.value = 1;
lambda.type = 'JtJ';
output_fn = ['recon_circle_1933_86_back_calibrated_005_edge' num2str(i)];
filter_n=0;

[fwd_mesh,pj_error] = reconstruct_stnd_cw_opt_fwd_exp(fwd_mesh,...
                                   data_fn,...
                                   iteration,...
                                   output_fn,...
                                   filter_n);
                              
mesh = load_mesh('circle_1933_86');
mesh1 = read_solution(mesh,output_fn);

end

mesh = load_mesh('circle_1933_86');

blob.x = 15;
blob.y = 0;
blob.r = 7.5;
blob.mua = 0.02;
blob.mus = 1;
blob.ri = 1.33;
blob.region = 2;

mesh_anom = add_blob(mesh,blob);

save_mesh(mesh_anom,'circle_1933_86_target');

mesh2 = load_mesh('circle_1933_86_target');

for i=1:5
    
    Tar(i) = 0.02+(i-1)*0.005;
    
    output_fn = ['recon_circle_1933_86_stnd_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh1 = read_solution(mesh,output_fn);
    
    in=find(mesh2.region(:)==2);
    val(i) = mean(mesh1.mua(in));
    
    output_fn = ['recon_circle_1933_86_back_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh1 = read_solution(mesh,output_fn);
    
    val_back(i) = mean(mesh1.mua(in));    
    
end


for i=6:9
    
    close all;
    
    Tar(i) = 0.04-(i-5)*0.005;
    
    output_fn = ['recon_circle_1933_86_stnd_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh1 = read_solution(mesh,output_fn);
    
    in=find(mesh2.region(:)==2);
    val(i) = mean(mesh1.mua(in));
    
    output_fn = ['recon_circle_1933_86_back_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh1 = read_solution(mesh,output_fn);
    
    val_back(i) = mean(mesh1.mua(in));    
    
end

for i=2:9
    close all
    Targ(i-1) = (Tar(i)-Tar(i-1))/Tar(i-1)*100;
    
    valg(i-1) = (val(i)-val(i-1))/val(i-1)*100;
    
    valg_back(i-1) = (val_back(i)-val_back(i-1))/val_back(i-1)*100;
end

np = 10;
np = -55 : ...
    ((55) - (-55)) ./ np : ...
     55;
 figure;
  subplot(4,1,1);
 hold on;
set(gca,'FontSize',16)
for i = 1 : 9

    if i<5
    mesh = load_mesh('circle_1933_86_target');
    in = find(mesh.region(:) == 2);
    mesh.mua(in) = 0.02+(i-1)*0.005;
    
  foo = mesh.nodes(:,2);
  foo(:) = np(1);
  trisurf(mesh.elements,...
	  mesh.nodes(:,1),...
      mesh.nodes(:,2)+(i*2.05*max(mesh.nodes(:,2))),...
      foo,...
	  mesh.mua(:)');

  %caxis([min(min(z_mus)) max(max(z_mus))]);
  caxis([0 0.04]);
  %caxis([0.53 2.56]);
  axis equal; axis tight;   shading interp; 
%   view(3);
  colormap hot; grid on; 
h = colorbar('horz');
set(h,'FontSize',16);
set(h,'FontWeight', 'bold');
set(h,'LineWidth', 1.5);
%set(h,'TickLength', [0.0125; 0.026]);
  view(-37.5,30);axis off; grid off
    else
     mesh = load_mesh('circle_1933_86_target');
    in = find(mesh.region(:) == 2);
    mesh.mua(in) = 0.04-(i-5)*0.005;
    
  foo = mesh.nodes(:,2);
  foo(:) = np(1);
  trisurf(mesh.elements,...
	  mesh.nodes(:,1),...
      mesh.nodes(:,2)+(i*2.05*max(mesh.nodes(:,2))),...
      foo,...
	  mesh.mua(:)');

  %caxis([min(min(z_mus)) max(max(z_mus))]);
  caxis([0 0.04]);
  %caxis([0.53 2.56]);
  axis equal; axis tight;   shading interp; 
%   view(3);
  colormap hot; grid on; 
h = colorbar('horz');
set(h,'FontSize',16);
set(h,'FontWeight', 'bold');
set(h,'LineWidth', 1.5);
%set(h,'TickLength', [0.0125; 0.026]);
  view(-37.5,30);axis off; grid off
    end
end
% title('\mu_a','FontSize',30,'FontWeight', 'bold');
  view(90, -90);
 
 subplot(4,1,2);
 hold on;
set(gca,'FontSize',16)
for i = 1 : 9
   
    output_fn = ['recon_circle_1933_86_stnd_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh = read_solution(mesh,output_fn);
 
  foo = mesh.nodes(:,2);
  foo(:) = np(1);
  trisurf(mesh.elements,...
	  mesh.nodes(:,1),...
      mesh.nodes(:,2)+(i*2.05*max(mesh.nodes(:,2))),...
      foo,...
	  mesh.mua(:)');

  %caxis([min(min(z_mus)) max(max(z_mus))]);
  caxis([0 0.04]);
  %caxis([0.53 2.56]);
  axis equal; axis tight;   shading interp; 
%   view(3);
  colormap hot; grid on; 
h = colorbar('horz');
set(h,'FontSize',16);
set(h,'FontWeight', 'bold');
set(h,'LineWidth', 1.5);
%set(h,'TickLength', [0.0125; 0.026]);
  view(-37.5,30);axis off; grid off
end
% title('\mu_a','FontSize',30,'FontWeight', 'bold');
  view(90, -90);
  
subplot(4,1,3);
 hold on;
set(gca,'FontSize',16)
for i = 1 : 9
  
    output_fn = ['recon_circle_1933_86_back_calibrated_005_edge' num2str(i-1)];
    mesh = load_mesh('circle_1933_86');
    mesh = read_solution(mesh,output_fn);
    
  foo = mesh.nodes(:,2);
  foo(:) = np(1);  
  trisurf(mesh.elements,...
	  mesh.nodes(:,1),...
      mesh.nodes(:,2)+(i*2.05*max(mesh.nodes(:,2))),...
      foo,...
	  mesh.mua(:)');

  %caxis([min(min(z_mus)) max(max(z_mus))]);
  caxis([0 0.04]);
  %caxis([0.53 2.56]);
  axis equal; axis tight;   shading interp; 
%   view(3);
  colormap hot; grid on; 
h = colorbar('horz');
set(h,'FontSize',16);
set(h,'FontWeight', 'bold');
set(h,'LineWidth', 1.5);
%set(h,'TickLength', [0.0125; 0.026]);
  view(-37.5,30);axis off; grid off
end
% title('\mu_a','FontSize',30,'FontWeight', 'bold');
  view(90, -90);


% figure;
subplot(4,1,4);
hold on;
plot(Targ,'-ko','MarkerSize',12);
plot(valg,'-rs','MarkerSize',12);
plot(valg_back,'-gd','MarkerSize',12);
legend('Target','Standard','Proposed');
hold off;
