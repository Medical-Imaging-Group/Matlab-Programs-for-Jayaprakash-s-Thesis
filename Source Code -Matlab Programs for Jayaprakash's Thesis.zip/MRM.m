function [ foo rn ]= MRM(J,foo,data_diff,alpha, ~)

%  eps = (0.0010)*norm(data_diff)^(2);
% if eps ==1
%     eps=1e-2;
% else
%     eps = 1e-6;
% end
eps = 1e-6;
r = J*foo - data_diff;

rprev = r ;
rn = norm(r,2)^2;

itt = 1; err_pj = 10;


 while err_pj >eps
    
    rn_p = norm(rprev,2)^2;
    
    
    ln = J'*r+ alpha * (foo);
    gn = J*ln;
    kn = (norm(ln,2)^2)/(norm(gn,2)^2 + alpha * norm(ln,2)^2);
    foo = foo - kn*ln;
    
    
    rprev =r;
    r = J*foo - data_diff;
    rn = norm(r,2)^2;
%     err_pj = ((rn_p - rn)/(rn_p))*100;
      err_pj = (rn_p - rn);

%     err_pj = rn + alpha*norm(foo)^2
    itt = itt +1;
    
 end
%  alpha



itt=itt-1;