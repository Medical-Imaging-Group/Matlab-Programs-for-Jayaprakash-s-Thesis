clear all;clc
% [J,data,mesh] = jacobian('mesh/2D_phantom',0);
% mesh.source.fwhm(:) = 3;
% [J,data,mesh] = jacobian(mesh,0);
% J = J.complete;
% save J J
% save mesh mesh

% load mesh
load mesh

% load Jacobian
load J

[nrow,ncol]=size(J);

% we have 350 frames of data, at a frame rate of 35Hz, therefore 10 seconds
% Using frame 1, as reference, reconstruct data from 2 -> 7 seconds
% i.e. frames 36:35:246 as in the Figure 13 of paper
% Daqing Piao et al, "Instrument for video-rate near-infrared diffuse
% optical tomography" Review of Scientific Instruments, 76 (2005)

% Need to calibrate data at t = 1 seconds
y_ref = load('processed/inject_ink_1.paa');
y_ref = y_ref(:,1);

% Calculate Hessian and inverse of regularized Hessian

% tic

[U,S,V]=svd(J);
diag_S = diag(S);
clear S;
UT = U.';
clear U;
SRc=[diag(diag_S) zeros(nrow,0);zeros(ncol-nrow,nrow) zeros(ncol-nrow,0)];

% reg_amp1 = max(diag(J*J')).*1e1 ;

lambda=10000;
reg_amp = (lambda/10^0.25)/3.5;

% diag_Sn = diag_S./ ((diag_S.^2) + (reg_amp));
% SRc(1:length(diag_Sn),1:length(diag_Sn)) = diag(diag_Sn);
% clear diag_Sn;
eval(['y_anom = load(''processed/inject_ink_' num2str(70) '.paa'');']);
y_anom = y_anom(:,1);
y = log(y_anom./y_ref);
alpha = reg_amp;
alpha = fminsearch(@(alpha) desecent_mu_objfun_JP(J, y, alpha),alpha, optimset( 'MaxIter', 1000, 'TolX', 1e-6));
update_eq = alpha*((J'));

k = 1;
for i = 70:4:111
    eval(['y_anom = load(''processed/inject_ink_' num2str(i) '.paa'');']);
    y_anom = y_anom(:,1);
    y = log(y_anom./y_ref);
    mua(k,:) = update_eq*y;
    k = k+1;
    %     pdesurf(mesh.nodes(:,1:2)',mesh.elements',mua(1,:)')
end

% time = toc;
% disp(['Initialisation Time =' num2str(time)]);

minu = min(min(mua));
maxu = max(max(mua));

figure;
% set(gca,'FontSize',28)
for i = 1 : k-1
    subplot(round(k/2),2,i);
    trisurf(mesh.elements,...
        mesh.nodes(:,1),...
        mesh.nodes(:,2),...
        mesh.nodes(:,3),...
        mua(i,:));
    max_mua = max(mua(i,:))
    % we will threshold like as in paper.
    %     caxis([minu maxu]);
%     caxis([0.001 maxu]);
    shading interp; view(2);
    axis equal; axis off; colormap hot;
    title(['t = ' num2str(i)]);
    colorbar ('horz');
end
